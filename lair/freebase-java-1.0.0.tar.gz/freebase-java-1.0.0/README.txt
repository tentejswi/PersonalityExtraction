



                         Freebase Java API
                         -----------------



  What is this?
  -------------

  This is a Java client API for accessing Freebase.com


  Where can I get more info?
  --------------------------
  
  Look at the freebase-java web site at
  
    http://code.google.com/p/freebase-java/
    

  Licensing and legal issues
  --------------------------

  This is open source software and is licensed under the BSD license
  located in the LICENSE.txt file located in the same directory as this very file
  you are reading.


                                --- o ---


  Thank you for your interest.



                                                 The Freebase Development Team
                                                    http://www.freebase.com/


